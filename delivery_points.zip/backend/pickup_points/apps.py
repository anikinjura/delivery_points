from django.apps import AppConfig


class PickupPointsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pickup_points'
